let body = document.querySelector("body");
let params = document.querySelector(".params");

let bn = document.querySelector("#inbutton");
let ni = document.querySelector("#inamount");
let amount = document.querySelector(".amount");

let quantity = 0;
let namings = [];
let amounts = [];
let namings_r = [];
let amounts_r = [];
let voters = [];
let runbtn = undefined;
let header = undefined;

let votesum = 0;

// Блок запроса информации

bn.addEventListener("click", () => {
  ni.value == "pog"
    ? (location = "https://www.youtube.com/watch?v=dQw4w9WgXcQ")
    : false;
  n = +ni.value;
  if (n.toString() == "NaN" || n < 2 || n > 5)
    return pulse(
      bn,
      "rgba(255, 0, 0, 1)",
      "rgba(255, 255, 255, 0.1)",
      0,
      0.2,
      0.3
    );
  bn.style.pointerEvents = "none";
  quantity = n;
  anime({
    targets: amount,
    height: 0,
    padding: 0,
    opacity: [1, 0],
    easing: "easeOutExpo",
    duration: 1.5 * 1000,
    loop: false,
  });
  setTimeout(() => {
    amount.remove();
    createArgs(n);
  }, 1500);
});

function createArgs(n) {
  params.innerHTML += `<div class="vote votingheader"><input type="text" class="voteheader" placeholder="Название голосования"></div>`;
  for (i = 0; i < n; ++i) {
    params.innerHTML += `<div class="vote">
        <input type="text" class="naming" placeholder="Название варианта">
        <input type="text" class="vamo" placeholder="Голосов">
    </div>`;
  }
  params.innerHTML += `<div class="vote votingheader"><button class="runbutton">Поехали</button></div>`;

  runbtn = document.querySelector(".runbutton");
  header = document.querySelector(".voteheader");
  voters = document.querySelectorAll(".vote");
  namings = document.querySelectorAll(".naming");
  amounts = document.querySelectorAll(".vamo");

  anime({
    targets: voters,
    height: "calc(1.4em + 20px)",
    duration: 1.5 * 1000,
    delay: anime.stagger(200, {
      grid: [1, n + 2],
    }),
    easing: "easeOutExpo",
    loop: false,
  });

  setTimeout(() => {
    runbtn.addEventListener("click", tryrun);
  }, 1.5 * 1000);
}

function tryrun() {
  if (
    header.value == "" ||
    header.value == undefined ||
    !header.value ||
    !voters ||
    !validateArr(namings) ||
    !validateIntArr(amounts)
  )
    return pulse(
      runbtn,
      "rgba(255, 0, 0, 1)",
      "rgba(255, 255, 255, 0.1)",
      0,
      0.2,
      0.3
    );
  runbtn.style.pointerEvents = "none";

  header = header.value;
  for (i = 0; i < namings.length; ++i) {
    namings_r[i] = namings[i].value;
    amounts_r[i] = +amounts[i].value;
    votesum += +amounts[i].value;
  }
  anime({
    targets: voters,
    opacity: [1, 0],
    easing: "easeOutExpo",
    duration: 1.5 * 1000,
    delay: anime.stagger(200, {
      grid: [1, n + 2],
    }),
    loop: false,
  });
  params.style.clipPath = "circle(0)";
  setTimeout(() => {
    document.querySelector(".ineedacertainid").remove();
    createResults();
  }, 1700);
}

// Конец блока запроса информации

// Начало блока уставшего Даниила

function sortEm() {
  for (i = 0; i < quantity - 1; ++i)
    for (j = 0; j < quantity - 1; ++j)
      if (amounts_r[j] < amounts_r[j + 1]) {
        tmp = amounts_r[j];
        amounts_r[j] = amounts_r[j + 1];
        amounts_r[j + 1] = tmp;
        tmp = namings_r[j];
        namings_r[j] = namings_r[j + 1];
        namings_r[j + 1] = tmp;
      }
}

function createResults() {
  sortEm();
  params.style.transition = "0s";
  params.style.height = "0px";
  params.style.clipPath = "none";
  params.style.justifyContent = "space-around";
  params.innerHTML = "";
  params.innerHTML += `<header>Результаты голосования ${header}</header>`;
  for (i = 0; i < quantity; ++i)
    params.innerHTML += `<div class="realvote"><span class="spacing">${namings_r[i]}</span><div class="bar"><span class="n${i}"></span>/${votesum}</div></div>`;

  votes_r = document.querySelectorAll(".realvote");
  bars = document.querySelectorAll(".bar");

  anime({
    targets: params,
    height: "600px",
    duration: 2000,
    loop: false,
  });
  let k = 0;
  let pog = setInterval(() => {
    console.log([k, votes_r, votes_r[k]]);
    anime({
      targets: votes_r[k],
      opacity: [0, 1],
      duration: 1500,
      loop: false,
    });
    setTimeout(() => {
      anime({
        targets: bars[k],
        width: ["0px", `${(amounts_r[k] / votesum) * 400}px`],
        duration: 1500,
        easing: "easeOutExpo",
        loop: false,
      });
      anime({
        targets: `.n${k}`,
        easing: "easeOutExpo",
        innerHTML: [0, amounts_r[k]],
        round: 1,
        duration: 1500,
        loop: false,
      });
      ++k;
    }, 500);
    k > quantity ? clearInterval(pog) : false;
  }, 500);
}

// Конец блока уставшего Даниила
